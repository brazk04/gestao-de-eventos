from django.db import models

# Create your models here.
class Evento(models.Model):
    nome = models.CharField(max_length=100)
    descricao = models.TextField()
    data_publicacao = models.DateTimeField(auto_now_add=True)
    data_evento = models.DateTimeField()    
    instituicao = models.CharField(max_length=100)
    local = models.CharField(max_length=100)
    ingressos  = models.IntegerField()
    valor = models.DecimalField(max_digits=5, decimal_places=2)
    usuario = models.ForeignKey('auth.User', on_delete=models.CASCADE, default=1)
    
    def __str__(self):
        return self.nome
    