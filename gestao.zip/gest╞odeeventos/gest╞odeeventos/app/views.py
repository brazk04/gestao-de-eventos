from django.shortcuts import render, redirect
from app.models import Evento
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

def entrar(request):
    if request.method == 'POST':
        email = request.POST.get('username')
        senha = request.POST.get('password')
        usuario = authenticate (username=email, password=senha)
        if usuario is not None:
            login(request, usuario)
            return redirect('index')
    return render(request, "entrar.html")

@login_required(login_url='/entrar/')
def index(request):
    dados = Evento.objects.all()
    return render(request, 'index.html', {'dados': dados})

def inserir(request):
    if request.method  == 'POST':
        nome = request.POST.get('nome')
        descricao = request.POST.get('descricao')
        data_evento = request.POST.get('data_evento')
        instituicao = request.POST.get('instituicao')
        local = request.POST.get('local')
        ingressos = request.POST.get('ingressos')
        valor = request.POST.get('valor')
        obj = Evento(nome=nome, descricao=descricao, data_evento=data_evento, instituicao=instituicao, local=local, ingressos=ingressos,  valor=valor)
        obj.save()
        return redirect('index')
    return render(request, 'inserir.html')

def deletar(request, id):
    dados = Evento.objects.get(id=id)
    dados.delete()
    return redirect('index')

def editare(request, id):
    evento = Evento.objects.get(id=id)
    if request.method  == 'POST':
        nome = request.POST.get('nome')
        descricao = request.POST.get('descricao')
        data_evento = request.POST.get('data_evento')
        instituicao = request.POST.get('instituicao')
        local = request.POST.get('local')
        ingressos = request.POST.get('ingressos')
        valor = request.POST.get('valor')
        evento.nome = nome
        evento.descricao = descricao
        evento.dataevento = data_evento
        evento.instituição = instituicao
        evento.local = local
        evento.ingressos = ingressos
        evento.valor= valor
        evento.save()
        return redirect('index')
    return render(request, 'editarevento.html',{'dados':evento})